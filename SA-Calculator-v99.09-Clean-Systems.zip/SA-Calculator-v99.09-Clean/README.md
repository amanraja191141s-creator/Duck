# SA Calculator v99.09 — Clean release and runtime audit

This release keeps exactly 12 tools: Currency Converter, Unit Converter, GST Calculator, Loan Calculator, Saving Calculator, Salary Calculator, Tip Calculator, SIP Calculator, Discount Calculator, Percentage Calculator, Age Calculator, and BMI Calculator.

The tool dashboard, tool field sizing, shared keypad, converter actions, and selected tool workflows are aligned to the supplied 2026-11-24 Android recording. Main/scientific calculator, history, settings, themes, localization, favorites, and the 12-tool registry are preserved.

## Release identity
- App version: `1.99.23-v99.09`
- Android versionCode: `1099138`

## Verify
```sh
npm run test:release
npm run build:web
```

Run `.github/workflows/main.yml` in GitHub Actions to build the Android debug APK. Physical-device touch, layout, performance, and APK validation remain required.
