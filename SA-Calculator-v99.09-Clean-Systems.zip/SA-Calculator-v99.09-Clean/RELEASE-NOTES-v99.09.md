# SA Calculator v99.09 — Clean release

- Removed superseded CSS override stacks and retained one authoritative reference UI layer.
- Removed stale release documents, obsolete standalone YAMLs, unused design-reference files and tests outside the release test suite.
- Hardened the shared tool keypad open/history lifecycle.
- Preserved all 12 requested calculator tools and their existing calculation engines.
- Rebuilt the Android web bundle and synchronized root/`www` assets.

App version: `1.99.23-v99.09`  
Android versionCode: `1099138`
