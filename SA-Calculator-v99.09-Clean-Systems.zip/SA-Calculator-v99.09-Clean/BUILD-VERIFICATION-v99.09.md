# Build verification — v99.09

## Release identity
- App version: `1.99.23-v99.09`
- Android versionCode: `1099138`
- Service-worker cache: `sa-calculator-v99-09-clean-release-v9909`

## Local verification
- `node --check assets/js/app.js` — passed
- `npm run build:web` — passed
- `npm run test:release` — passed: 62 tests, 0 failures.
- Root and generated `www/` copies of HTML, JavaScript, CSS and service worker are checked for byte identity by regression tests.
- Standalone Android YAML is checked against `.github/workflows/main.yml`.
- ZIP integrity is checked after packaging.

## Not claimed
- No physical Android handset/touch test was run in this environment.
- No fresh GitHub-hosted Actions run or APK artifact is claimed by this local report.
- CSS parser: 0 top-level syntax errors in both stylesheets.
- HTML IDs: 0 duplicates.
- CI workflow YAML: valid; standalone and repository workflow files are byte-identical.
- Root/generated `www/` copies: byte-identical for HTML, CSS, JS and service worker.
- Package cleanup: historical root reports and old YAMLs removed; 10 active release tests retained.
